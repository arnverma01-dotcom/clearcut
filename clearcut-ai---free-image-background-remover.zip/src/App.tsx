import { useState, useCallback, useRef, ChangeEvent, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Upload, 
  Image as ImageIcon, 
  Download, 
  X, 
  RefreshCw, 
  Check, 
  ArrowRight,
  ShieldCheck,
  Zap,
  CheckCircle2,
  Info
} from "lucide-react";
import { removeBackground } from "@imgly/background-removal";
import { cn } from "./lib/utils";

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Helper to format bytes
const formatBytes = (bytes: number, decimals = 2) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

// Ad unit component
const AdUnit = ({ className, slot }: { className?: string; slot?: string }) => {
  const adClientId = import.meta.env.VITE_ADSENSE_CLIENT_ID;
  const isEnabled = adClientId && adClientId !== '' && adClientId !== 'ca-pub-XXXXXXXXXXXXXXXX';

  useEffect(() => {
    if (!isEnabled) return;

    // Dynamically inject the script if it's not already there
    const scriptId = 'adsense-script';
    if (!document.getElementById(scriptId)) {
      const script = document.createElement('script');
      script.id = scriptId;
      script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${adClientId}`;
      script.async = true;
      script.crossOrigin = 'anonymous';
      document.head.appendChild(script);
    }

    try {
      // @ts-ignore
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch (e) {
      console.error("AdSense error:", e);
    }
  }, [isEnabled, adClientId]);

  if (!isEnabled) return null;

  return (
    <div className={cn("bg-slate-50 border border-slate-100 rounded-xl overflow-hidden flex items-center justify-center min-h-[90px] relative transition-all hover:bg-slate-100/50", className)}>
      <span className="text-[8px] font-black uppercase tracking-[0.3em] text-slate-300 absolute top-2 right-4">Advertisement</span>
      <ins
        className="adsbygoogle"
        style={{ display: "block", width: "100%", height: "100%" }}
        data-ad-client={adClientId}
        data-ad-slot={slot || "XXXXXXXXXX"}
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
    </div>
  );
};

export default function App() {
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fileInfo, setFileInfo] = useState<{ name: string; size: number } | null>(null);
  const [progress, setProgress] = useState(0);
  const [processingState, setProcessingState] = useState<string>("");
  const [modelType, setModelType] = useState<"isnet" | "isnet_fp16" | "isnet_quint8">("isnet_fp16");
  const [precision, setPrecision] = useState(false);
  const [processedQueue, setProcessedQueue] = useState<{url: string, original: string, name: string}[]>([]);
  const [currentIndex, setCurrentIndex] = useState(-1);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [viewMode, setViewMode] = useState<'result' | 'comparison' | 'side-by-side'>('result');
  const [fastMode, setFastMode] = useState(true);
  const [previewBg, setPreviewBg] = useState<'checkerboard' | 'white' | 'black' | 'custom'>('checkerboard');
  const [customBgColor, setCustomBgColor] = useState('#6366f1');
  const [sliderPosition, setSliderPosition] = useState(50);
  const sliderRef = useRef<HTMLDivElement>(null);

  const handleProcessImage = useCallback(async (imageSource: string | File, currentModel = modelType, currentPrecision = precision) => {
    setIsProcessing(true);
    setError(null);
    setProgress(0);
    setProcessingState("Initializing AI...");

    const config = {
      model: currentModel,
      rescale: !currentPrecision, // Invert: precision=true means rescale=false (process at full res)
      proxyToWorker: true,
      output: {
        format: 'image/png' as const,
        quality: 1.0
      },
      progress: (state: string, progress: number, total: number) => {
        setProcessingState(state === 'fetch' ? 'Loading AI Model' : state === 'compute' ? 'Removing Background' : 'Refining Edges');
        const percent = Math.round((progress / (total || 1)) * 100);
        setProgress(percent || Math.round(progress * 100));
      }
    };

    try {
      const blob = await removeBackground(imageSource, config);
      const url = URL.createObjectURL(blob);
      setProcessedImage(url);

      const fileName = typeof imageSource === 'string' ? 'demo.png' : imageSource.name;
      const originalUrl = typeof imageSource === 'string' ? imageSource : URL.createObjectURL(imageSource);
      
      setProcessedQueue(prev => [{ url, original: originalUrl, name: fileName }, ...prev]);
      setCurrentIndex(0);
    } catch (err: any) {
      console.error("Background removal error:", err);
      setError("Failed to process. Ultra mode on large images may require more memory.");
    } finally {
      setIsProcessing(false);
      setProgress(100);
    }
  }, [modelType, precision]);

  const onFileChange = useCallback(async (e: ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;

    const files = Array.from(fileList) as File[];
    const validFiles = files.filter(f => f.type.startsWith("image/"));
    
    if (validFiles.length === 0) {
      setError("Please select valid image files.");
      return;
    }

    // Set first for immediate UI feedback
    const firstFile = validFiles[0];
    setFileInfo({ name: firstFile.name, size: firstFile.size });
    setOriginalImage(URL.createObjectURL(firstFile));
    setProcessedImage(null);

    // Process the batch sequentially
    for (const file of validFiles) {
      await handleProcessImage(file);
    }
  }, [handleProcessImage]);

  const reset = () => {
    setOriginalImage(null);
    setProcessedImage(null);
    setIsProcessing(false);
    setError(null);
    setFileInfo(null);
    setProgress(0);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const downloadImage = () => {
    if (!processedImage) return;
    const link = document.createElement("a");
    link.href = processedImage;
    link.download = `clearcut-${fileInfo?.name.split('.')[0] || 'processed'}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const demoImages = [
    {
      id: 1,
      url: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=600&auto=format&fit=crop",
      title: "Product"
    },
    {
      id: 2,
      url: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=600&auto=format&fit=crop",
      title: "Portrait"
    },
    {
      id: 3,
      url: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=600&auto=format&fit=crop",
      title: "Landscape"
    }
  ];

  const handleDemoSelect = (url: string) => {
    setFileInfo({ name: "demo-image.jpg", size: 0 });
    setOriginalImage(url);
    setProcessedImage(null);
    handleProcessImage(url);
  };

  const handleSliderMove = (e: any) => {
    if (!sliderRef.current) return;
    const rect = sliderRef.current.getBoundingClientRect();
    const x = e.touches ? e.touches[0].clientX : e.clientX;
    const position = ((x - rect.left) / rect.width) * 100;
    setSliderPosition(Math.max(0, Math.min(100, position)));
  };

  const handleModelChange = (newModel: "isnet" | "isnet_fp16" | "isnet_quint8") => {
    setModelType(newModel);
    if (newModel === 'isnet_quint8') {
      setFastMode(true);
      setPrecision(false);
    } else {
      setFastMode(false);
    }
    if (originalImage) {
      handleProcessImage(originalImage, newModel, newModel === 'isnet_quint8' ? false : precision);
    }
  };

  const toggleFastMode = () => {
    const nextFast = !fastMode;
    setFastMode(nextFast);
    if (nextFast) {
      setModelType('isnet_quint8');
      setPrecision(false);
      if (originalImage) handleProcessImage(originalImage, 'isnet_quint8', false);
    } else {
      setModelType('isnet_fp16');
      if (originalImage) handleProcessImage(originalImage, 'isnet_fp16', precision);
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFCFB] text-slate-900 font-sans selection:bg-indigo-100 selection:text-indigo-900 flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-18 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={reset}>
            <div className="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-100 group-hover:scale-105 transition-all duration-300">
              <RefreshCw className={cn("w-6 h-6 text-white", isProcessing && "animate-spin")} />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-black tracking-tight text-slate-900 font-display leading-none">ClearCut<span className="text-indigo-600">AI</span></span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Free HD Background Remover</span>
            </div>
          </div>
          
          <div className="flex items-center gap-8">
            <nav className="flex items-center p-1.5 bg-slate-100/50 rounded-2xl border border-slate-100">
              <button 
                onClick={() => handleModelChange('isnet_quint8')}
                className={cn(
                  "px-4 py-2 text-[10px] font-bold uppercase tracking-widest rounded-xl transition-all",
                  modelType === 'isnet_quint8' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                )}
              >
                Fast Mode
              </button>
              <button 
                onClick={() => handleModelChange('isnet_fp16')}
                className={cn(
                  "px-4 py-2 text-[10px] font-bold uppercase tracking-widest rounded-xl transition-all",
                  modelType === 'isnet_fp16' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                )}
              >
                Ultra HD
              </button>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-1 pb-20">
        {/* Landing Page Content (Visible when no image is uploaded) */}
        {!originalImage && (
          <>
            <div className="max-w-7xl mx-auto px-4 pt-8">
              <AdUnit className="h-24 md:h-32 mb-8" slot="top-horizontal" />
            </div>
            <section className="pt-20 pb-12 px-4">
              <div className="max-w-3xl mx-auto text-center space-y-6">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6 }}
                >
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-semibold uppercase tracking-wider mb-4">
                    <Zap className="w-3 h-3" />
                    100% Free AI Background Remover
                  </div>
                  <h1 className="text-5xl md:text-8xl font-black tracking-tighter text-slate-900 mb-6 font-display leading-[0.9]">
                    Remove <br />
                    Backgrounds <br />
                    <span className="text-indigo-600 italic">in a Blink.</span>
                  </h1>
                  <p className="text-lg text-slate-500 max-w-xl mx-auto leading-relaxed">
                    ClearCut AI is an <strong>automatic background remover</strong> and <strong>transparent background maker</strong>. <strong>Erase image background</strong> online free, instantly, and with professional precision directly in your browser.
                  </p>
                </motion.div>

                {/* Upload Area */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  className="mt-12"
                >
                  <label 
                    className={cn(
                      "relative group block max-w-xl mx-auto p-12 border-2 border-dashed border-slate-200 rounded-[2.5rem] bg-white transition-all cursor-pointer hover:border-indigo-400 hover:bg-indigo-50/30 active:scale-98",
                      error && "border-red-300 bg-red-50"
                    )}
                  >
                    <input 
                      type="file" 
                      className="hidden" 
                      onChange={onFileChange} 
                      accept="image/*"
                      multiple
                      ref={fileInputRef}
                    />
                    <div className="flex flex-col items-center">
                      <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-indigo-100 group-hover:scale-110 transition-all duration-300">
                        <Upload className="w-8 h-8 text-slate-400 group-hover:text-indigo-600" />
                      </div>
                      <span className="text-lg font-semibold text-slate-700 group-hover:text-indigo-900">
                        Image background remove online free
                      </span>
                      <span className="text-sm text-slate-400 mt-1">
                        Free png background remove online - Drag & drop anywhere
                      </span>
                      <div className="mt-8 flex items-center gap-4">
                        {demoImages.map((demo) => (
                          <button 
                            key={demo.id}
                            onClick={(e) => {
                              e.preventDefault();
                              handleDemoSelect(demo.url);
                            }}
                            className="group/demo relative w-12 h-12 rounded-lg overflow-hidden border border-slate-200 hover:border-indigo-400 transition-colors shadow-sm"
                          >
                            <img src={demo.url} className="w-full h-full object-cover transition-transform group-hover/demo:scale-110" referrerPolicy="no-referrer" />
                            <div className="absolute inset-0 bg-slate-900/0 group-hover/demo:bg-slate-900/10 transition-colors" />
                          </button>
                        ))}
                      </div>
                    </div>
                  </label>
                  {error && (
                    <p className="mt-4 text-red-500 text-sm font-medium flex items-center justify-center gap-1">
                      <Info className="w-4 h-4" /> {error}
                    </p>
                  )}
                </motion.div>

                <div className="mt-16 grid grid-cols-2 md:grid-cols-3 gap-8 max-w-2xl mx-auto pt-12 border-t border-slate-100">
                  <div className="flex flex-col items-center gap-2">
                    <ShieldCheck className="w-6 h-6 text-indigo-500" />
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Private AI Removal</span>
                  </div>
                  <div className="flex flex-col items-center gap-2">
                    <Zap className="w-6 h-6 text-indigo-500" />
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Instant Online App</span>
                  </div>
                  <div className="flex flex-col items-center gap-2 col-span-2 md:col-span-1">
                    <CheckCircle2 className="w-6 h-6 text-indigo-500" />
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">High Quality HD</span>
                  </div>
                </div>
              </div>
            </section>

            {/* SEO Content Sections */}
            <section className="py-20 bg-slate-50">
              <div className="max-w-5xl mx-auto px-4">
                <AdUnit className="mb-20 h-64" slot="seo-mid" />
                <div className="grid md:grid-cols-2 gap-16 items-center">
                  <div>
                    <h2 className="text-3xl font-black font-display uppercase tracking-tight text-slate-900 mb-6">
                      Best Free Background Remover Online
                    </h2>
                    <p className="text-slate-600 mb-6 leading-relaxed">
                      ClearCut AI is the ultimate solution for <strong>image background remove online free</strong>. Whether you need a <strong>white background remove online</strong> or want to <strong>remove background online and make png</strong>, our advanced AI handles it all without the cost of premium tools like <strong>Adobe Express</strong> or <strong>Photoroom</strong>.
                    </p>
                    <ul className="space-y-4">
                      {[
                        "Free background remover online - no watermark or login",
                        "Signature background remove online instantly for docs",
                        "Logo background remove online free for branding",
                        "Remove background from image online free high resolution HD",
                        "Jpg & PNG background remove online with AI accuracy",
                        "Unlimited free background remover - no sign up required"
                      ].map((item, i) => (
                        <li key={i} className="flex items-start gap-3 text-sm font-medium text-slate-500">
                          <Check className="w-4 h-4 text-indigo-500 mt-0.5 shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="bg-white p-8 rounded-[2rem] shadow-xl border border-slate-100">
                    <h3 className="text-xl font-black font-display mb-4 uppercase tracking-wider">How to remove background online?</h3>
                    <div className="space-y-6">
                      <div className="flex gap-4">
                        <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold shrink-0">1</div>
                        <div>
                          <p className="font-bold text-slate-800">Upload your image</p>
                          <p className="text-xs text-slate-500">Support for JPG, PNG, WEBP, and signatures.</p>
                        </div>
                      </div>
                      <div className="flex gap-4">
                        <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold shrink-0">2</div>
                        <div>
                          <p className="font-bold text-slate-800">Automatic AI Removal</p>
                          <p className="text-xs text-slate-500">Our background remover online uses deep learning to isolate subjects instantly.</p>
                        </div>
                      </div>
                      <div className="flex gap-4">
                        <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold shrink-0">3</div>
                        <div>
                          <p className="font-bold text-slate-800">Download HD Results</p>
                          <p className="text-xs text-slate-500">Get a free png background remove online result in high quality (4K supported).</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section className="py-20 px-4 border-b border-slate-100">
              <div className="max-w-5xl mx-auto">
                <div className="text-center mb-16">
                  <h2 className="text-3xl font-black font-display uppercase tracking-tight text-slate-900 mb-4">Professional Use Cases</h2>
                  <p className="text-slate-500 text-sm max-w-xl mx-auto font-medium">Why ClearCut AI is the <strong>best background remover tool</strong> for creators and businesses.</p>
                </div>
                <div className="grid md:grid-cols-3 gap-8">
                  <div className="p-8 bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
                    <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center mb-6">
                      <Zap className="w-6 h-6 text-indigo-600" />
                    </div>
                    <h3 className="font-bold text-slate-900 mb-3">E-commerce & Products</h3>
                    <p className="text-xs leading-relaxed text-slate-500">Perfect <strong>remove background from product image</strong> for <strong>Amazon product images</strong>, <strong>Shopify products</strong>, and <strong>e-commerce</strong>. Create <strong>transparent background maker</strong> results for <strong>car photos</strong> and catalog shots.</p>
                  </div>
                  <div className="p-8 bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
                    <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center mb-6">
                      <CheckCircle2 className="w-6 h-6 text-indigo-600" />
                    </div>
                    <h3 className="font-bold text-slate-900 mb-3">Logos & Signatures</h3>
                    <p className="text-xs leading-relaxed text-slate-500">The ultimate <strong>logo background remove online</strong> and <strong>signature background remover online free</strong>. Easily <strong>remove background from logo</strong>, <strong>remove background from signature</strong>, or <strong>remove background from scanned document</strong>.</p>
                  </div>
                  <div className="p-8 bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
                    <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center mb-6">
                      <ShieldCheck className="w-6 h-6 text-indigo-600" />
                    </div>
                    <h3 className="font-bold text-slate-900 mb-3">Portrait & Identity</h3>
                    <p className="text-xs leading-relaxed text-slate-500"><strong>Remove background from portrait photo</strong>, <strong>selfies</strong>, and <strong>profile pictures</strong>. Optimized for <strong>passport photos</strong> and <strong>ID photos</strong>. Make <strong>remove background and add white background</strong> edits instantly.</p>
                  </div>
                </div>
              </div>
            </section>

            <div className="max-w-5xl mx-auto px-4 py-8">
              <AdUnit className="h-40" slot="mid-landing" />
            </div>

            <section className="py-20 bg-slate-900 text-white overflow-hidden relative">
              <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/4 w-96 h-96 bg-indigo-500/20 blur-[120px] rounded-full" />
              <div className="max-w-5xl mx-auto px-4 relative z-10">
                <div className="flex flex-col md:flex-row items-center justify-between gap-12">
                  <div className="max-w-md">
                    <h2 className="text-4xl font-black font-display uppercase tracking-tight mb-6 leading-tight">Advanced AI Format Support</h2>
                    <p className="text-slate-400 text-sm leading-relaxed mb-8">
                      We support all major web and print formats. Our <strong>image background remover online app</strong> ensures zero quality loss during the process.
                    </p>
                    <div className="grid grid-cols-3 gap-4">
                      {['JPG', 'PNG', 'WEBP', 'GIF', 'HEIC', 'BMP'].map((ext) => (
                        <div key={ext} className="px-4 py-2 bg-slate-800 rounded-lg border border-slate-700 text-center text-[10px] font-bold tracking-widest text-indigo-400">
                          {ext}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-slate-800/50 backdrop-blur-xl p-8 rounded-[2.5rem] border border-slate-700 w-full max-w-sm">
                    <p className="text-indigo-400 text-[10px] font-black uppercase tracking-[0.2em] mb-4">Laboratory Features</p>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-slate-300"><strong>Batch AI Removal</strong></span>
                        <span className="text-[8px] px-2 py-0.5 bg-green-500/20 text-green-400 rounded-full font-bold uppercase tracking-widest">Active</span>
                      </div>
                      <div className="flex items-center gap-3 opacity-50">
                        <div className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                        <span className="text-xs text-slate-300"><strong>Video Remove Online</strong> (Beta)</span>
                      </div>
                      <div className="flex items-center gap-3 opacity-50">
                        <div className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                        <span className="text-xs text-slate-300"><strong>Audio AI Enhancer</strong></span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section className="py-20 px-4">
              <div className="max-w-4xl mx-auto">
                <h2 className="text-3xl font-black font-display text-center uppercase tracking-tight text-slate-900 mb-12">
                  Frequently Asked Questions
                </h2>
                <AdUnit className="mb-12 h-32" slot="faq-top" />
                <div className="grid md:grid-cols-2 gap-x-12 gap-y-10">
                  <div>
                    <h3 className="font-bold text-slate-900 mb-2">Is this background remover online free?</h3>
                    <p className="text-slate-500 text-[13px] leading-relaxed">Yes! ClearCut AI is a 100% <strong>free background remover online</strong>. Unlike <strong>Adobe background remove online</strong> or <strong>Canva background remover</strong>, we don't require credit cards. You can <strong>remove background online and free</strong> instantly.</p>
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 mb-2">Can I remove signature background online?</h3>
                    <p className="text-slate-500 text-[13px] leading-relaxed">Absolutely. Our tool is optimized as a <strong>signature background remover online free</strong>. <strong>Erase image background</strong> from <strong>scanned documents</strong> or <strong>signatures</strong> while keeping the ink <strong>hd quality</strong>.</p>
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 mb-2">How do I get background remove online hd quality?</h3>
                    <p className="text-slate-500 text-[13px] leading-relaxed">For a <strong>remove photo background online high quality free</strong> result, upload your original high-res image. Our <strong>ai photo cutout tool</strong> supports <strong>remove image background in hd quality</strong> for all downloads.</p>
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 mb-2">Do you support bulk remove background online free?</h3>
                    <p className="text-slate-500 text-[13px] leading-relaxed">Yes! Simply select multiple images. ClearCut AI's <strong>bulk background remover</strong> and <strong>batch remove background images</strong> feature will process them using <strong>one click background remover</strong> technology.</p>
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 mb-2">How is this different from Adobe Express or Photoroom?</h3>
                    <p className="text-slate-500 text-[13px] leading-relaxed">ClearCut AI is 100% on-device. It's an <strong>instant background remover</strong> that works <strong>without photoshop</strong>. Your images never leave your computer, making it the most private <strong>ai background remove online</strong> tool.</p>
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 mb-2">Can I remove video background online free?</h3>
                    <p className="text-slate-500 text-[13px] leading-relaxed">Currently, we specialize in images like <strong>remove background from jpeg</strong>, <strong>jpg</strong>, and <strong>png</strong>. Our <strong>remove video background online free</strong> feature is in active development for Q3 2024.</p>
                  </div>
                </div>
              </div>
            </section>
          </>
        )}

        {/* Processing/Result View */}
        {originalImage && (
          <section className="max-w-7xl mx-auto px-4 pt-12">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-[2.5rem] shadow-2xl shadow-indigo-100 overflow-hidden border border-slate-100"
            >
              <div className="p-4 md:p-8 flex flex-col md:flex-row gap-8">
                {/* Previews Sidebar */}
                <div className="w-full md:w-80 flex flex-col gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="font-black text-slate-800 font-display uppercase tracking-wider text-xs">Original</h3>
                      {fileInfo && <span className="text-[10px] font-mono text-slate-400 uppercase tracking-tighter">{formatBytes(fileInfo.size)}</span>}
                    </div>
                    <div className="aspect-square relative rounded-2xl overflow-hidden bg-slate-50 border border-slate-100">
                      <img src={originalImage} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                      <button 
                        onClick={reset}
                        className="absolute top-2 right-2 w-8 h-8 bg-slate-900/50 backdrop-blur-sm text-white rounded-full flex items-center justify-center hover:bg-slate-900 transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                      <div className="flex flex-col gap-4 mt-auto">
                        <button 
                          onClick={toggleFastMode}
                          className={cn(
                            "flex items-center justify-between w-full p-4 rounded-2xl border transition-all text-left",
                            fastMode 
                              ? "bg-amber-50 border-amber-200 text-amber-900 shadow-sm" 
                              : "bg-white border-slate-100 text-slate-600 hover:border-slate-300"
                          )}
                        >
                          <div className="flex items-center gap-3">
                            <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center transition-colors", fastMode ? "bg-amber-500 text-white" : "bg-slate-100 text-slate-400")}>
                              <Zap className={cn("w-5 h-5", fastMode && "fill-white")} />
                            </div>
                            <div>
                              <p className="font-bold text-xs uppercase tracking-wider">Fast Mode</p>
                              <p className="text-[10px] opacity-70 underline decoration-dotted">Instant results (Optimized AI)</p>
                            </div>
                          </div>
                          <div className={cn("w-10 h-6 rounded-full relative transition-colors duration-300", fastMode ? "bg-amber-500" : "bg-slate-200")}>
                            <div className={cn("absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300", fastMode ? "left-5 shadow-md" : "left-1")} />
                          </div>
                        </button>

                        {!fastMode && (
                          <button 
                            onClick={() => {
                              const newPrecision = !precision;
                              setPrecision(newPrecision);
                              if (originalImage) handleProcessImage(originalImage, modelType, newPrecision);
                            }}
                            className={cn(
                              "flex items-center justify-between w-full p-4 rounded-2xl border transition-all text-left",
                              precision 
                                ? "bg-indigo-50 border-indigo-200 text-indigo-900 shadow-sm" 
                                : "bg-white border-slate-100 text-slate-600 hover:border-slate-300"
                            )}
                          >
                            <div className="flex items-center gap-3">
                              <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center transition-colors", precision ? "bg-indigo-500 text-white" : "bg-slate-100 text-slate-400")}>
                                <CheckCircle2 className="w-5 h-5" />
                              </div>
                              <div>
                                <p className="font-bold text-xs uppercase tracking-wider">HD Precision</p>
                                <p className="text-[10px] opacity-70 underline decoration-dotted">Refined edges & hair details</p>
                              </div>
                            </div>
                            <div className={cn("w-10 h-6 rounded-full relative transition-colors duration-300", precision ? "bg-indigo-500" : "bg-slate-200")}>
                              <div className={cn("absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300", precision ? "left-5 shadow-md" : "left-1")} />
                            </div>
                          </button>
                        )}
                        
                        {fastMode && (
                          <div className="p-3 bg-indigo-50/50 rounded-xl border border-indigo-100/50">
                            <p className="text-[9px] font-bold text-indigo-600 uppercase tracking-tight mb-1">💡 Quality Tip</p>
                            <p className="text-[9px] text-slate-500 leading-tight">Disable <span className="font-bold uppercase tracking-widest text-amber-600">Fast Mode</span> for <span className="font-bold">HD Precision</span> on complex images like portraits with hair.</p>
                          </div>
                        )}
                        
                        <AdUnit className="mt-4" slot="sidebar-lower" />

                        <div className="p-4 bg-slate-50 rounded-2xl space-y-3">
                      <div className="flex items-center gap-2 text-sm">
                        <Check className="w-4 h-4 text-green-500" />
                        <span className="text-slate-600">Full Resolution</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Check className="w-4 h-4 text-green-500" />
                        <span className="text-slate-600">Pure Transparency</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Check className="w-4 h-4 text-green-500" />
                        <span className="text-slate-600">Browser Processing</span>
                      </div>
                    </div>
                    
                    <button 
                      disabled={!processedImage}
                      onClick={downloadImage}
                      className={cn(
                        "flex items-center justify-center gap-2 w-full py-4 rounded-2xl font-bold transition-all shadow-lg shadow-indigo-200 active:scale-95",
                        processedImage 
                          ? "bg-indigo-600 text-white hover:bg-indigo-700" 
                          : "bg-slate-100 text-slate-400 cursor-not-allowed shadow-none"
                      )}
                    >
                      <Download className="w-5 h-5" />
                      Download HD
                    </button>
                    
                    <button 
                      onClick={reset}
                      className="w-full py-3 rounded-2xl font-medium text-slate-500 hover:text-slate-800 transition-colors text-sm"
                    >
                      Start New
                    </button>
                    
                    <AdUnit className="mt-4 min-h-[250px]" slot="sidebar-vertical" />
                  </div>

                  {/* Batch Queue */}
                  {processedQueue.length > 0 && (
                    <div className="mt-8 space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="font-black text-slate-800 font-display uppercase tracking-wider text-[10px]">Session History</h3>
                        {processedQueue.length > 1 && (
                          <button 
                            onClick={() => {
                              processedQueue.forEach((item, index) => {
                                setTimeout(() => {
                                  const link = document.createElement("a");
                                  link.href = item.url;
                                  link.download = `clearcut-batch-${index}-${item.name}`;
                                  document.body.appendChild(link);
                                  link.click();
                                  document.body.removeChild(link);
                                }, index * 300); // Stagger downloads to prevent browser blocking
                              });
                            }}
                            className="text-[9px] font-bold text-indigo-600 uppercase tracking-widest hover:underline"
                          >
                            Download All
                          </button>
                        )}
                      </div>
                      <div className="grid grid-cols-3 gap-3">
                        {processedQueue.map((item, id) => (
                          <button 
                            key={id}
                            onClick={() => {
                              setProcessedImage(item.url);
                              setOriginalImage(item.original);
                              setFileInfo({ name: item.name, size: 0 });
                            }}
                            className={cn(
                              "aspect-square rounded-xl overflow-hidden border-2 transition-all p-1",
                              processedImage === item.url ? "border-indigo-600 bg-indigo-50" : "border-slate-100 hover:border-slate-300 bg-white"
                            )}
                          >
                            <img src={item.url} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Main Viewport */}
                <div className="flex-1 relative min-h-[400px] md:min-h-[600px] rounded-[2rem] overflow-hidden border border-slate-100 bg-slate-50 flex flex-col">
                  {/* Tabs */}
                  {processedImage && !isProcessing && (
                    <div className="absolute top-6 right-6 z-20 flex p-1 bg-white/80 backdrop-blur-sm rounded-xl border border-slate-100 shadow-sm">
                      <button 
                        onClick={() => setViewMode('result')}
                        className={cn(
                          "px-4 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-lg transition-all",
                          viewMode === 'result' ? "bg-slate-900 text-white shadow-sm" : "text-slate-400 hover:text-slate-600"
                        )}
                      >
                        Result
                      </button>
                      <button 
                        onClick={() => setViewMode('comparison')}
                        className={cn(
                          "px-4 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-lg transition-all",
                          viewMode === 'comparison' ? "bg-slate-900 text-white shadow-sm" : "text-slate-400 hover:text-slate-600"
                        )}
                      >
                        Compare
                      </button>
                    </div>
                  )}

                  {/* Canvas Area */}
                  <div className="flex-1 relative overflow-hidden flex flex-col">
                    {/* Background Layer */}
                    <div className="absolute inset-0 z-0 transition-colors duration-300" style={{ backgroundColor: previewBg === 'white' ? 'white' : previewBg === 'black' ? 'black' : previewBg === 'custom' ? customBgColor : 'transparent' }}>
                      {previewBg === 'checkerboard' && (
                        <div 
                          className="absolute inset-0" 
                          style={{ 
                            backgroundImage: 'radial-gradient(#e5e7eb 1px, transparent 1px)', 
                            backgroundSize: '20px 20px',
                            backgroundColor: '#f9fafb'
                          }} 
                        />
                      )}
                    </div>
                    
                    <AnimatePresence mode="wait">
                      {isProcessing ? (
                        <motion.div 
                          key="processing"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-white/80 backdrop-blur-md"
                        >
                          <div className="relative w-32 h-32 mb-8">
                            <svg className="w-full h-full -rotate-90">
                              <circle
                                cx="64"
                                cy="64"
                                r="58"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="8"
                                className="text-slate-100"
                              />
                              <motion.circle
                                cx="64"
                                cy="64"
                                r="58"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="8"
                                strokeDasharray="364.4"
                                initial={{ strokeDashoffset: 364.4 }}
                                animate={{ strokeDashoffset: 364.4 - (364.4 * progress) / 100 }}
                                className="text-indigo-600"
                                strokeLinecap="round"
                              />
                            </svg>
                            <div className="absolute inset-0 flex items-center justify-center">
                              <span className="text-xl font-black text-slate-800">{progress}%</span>
                            </div>
                          </div>
                          <h2 className="text-3xl font-black tracking-tight text-slate-800 font-display uppercase">
                            {processingState === 'fetch' ? 'Downloading AI Model...' : 
                             processingState === 'compute' ? 'Removing Background...' :
                             'Processing...'}
                          </h2>
                          <p className="text-slate-500 mt-2 font-semibold uppercase tracking-widest text-[10px]">
                            {processingState === 'fetch' ? 'Models are cached after the first run' : 
                             'Almost there, AI is doing the heavy lifting'}
                          </p>
                        </motion.div>
                      ) : processedImage ? (
                        <motion.div 
                          key={viewMode}
                          initial={{ opacity: 0, scale: 0.98 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="absolute inset-0 z-10 flex items-center justify-center"
                        >
                          {viewMode === 'result' ? (
                            <div className="w-full h-full p-4 md:p-12 flex items-center justify-center">
                              <img 
                                src={processedImage} 
                                className="max-w-full max-h-full object-contain drop-shadow-[0_20px_50px_rgba(0,0,0,0.15)]" 
                                alt="Processed" 
                              />
                            </div>
                          ) : viewMode === 'comparison' ? (
                            <div 
                              ref={sliderRef}
                              className="relative w-full h-full cursor-col-resize select-none overflow-hidden"
                              onMouseMove={handleSliderMove}
                              onTouchMove={handleSliderMove}
                            >
                              {/* Background/After Image */}
                              <div className="absolute inset-0">
                                <img src={processedImage} className="w-full h-full object-contain p-4 md:p-12" alt="After" />
                                <div className="absolute bottom-6 right-6 px-3 py-1 bg-indigo-600 text-[10px] text-white font-bold rounded-lg uppercase tracking-wider z-20">After</div>
                              </div>
                              
                              {/* Foreground/Before Image */}
                              <div 
                                className="absolute inset-0 overflow-hidden" 
                                style={{ width: `${sliderPosition}%`, borderRight: '2px solid white' }}
                              >
                                <div className="absolute inset-0 w-[100vw] h-full" style={{ width: sliderRef.current?.offsetWidth }}>
                                  <img src={originalImage!} className="w-full h-full object-contain p-4 md:p-12" alt="Original" />
                                </div>
                                <div className="absolute bottom-6 left-6 px-3 py-1 bg-slate-900/50 backdrop-blur-md text-[10px] text-white font-bold rounded-lg uppercase tracking-wider z-20">Before</div>
                              </div>

                              {/* Slider Handle */}
                              <div 
                                className="absolute top-0 bottom-0 z-30"
                                style={{ left: `${sliderPosition}%` }}
                              >
                                <div className="absolute top-1/2 left-0 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full shadow-xl flex items-center justify-center border-2 border-indigo-600">
                                  <ArrowRight className="w-4 h-4 text-indigo-600 rotate-180" />
                                  <ArrowRight className="w-4 h-4 text-indigo-600" />
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="w-full h-full flex flex-col md:grid md:grid-cols-2 gap-4 p-4 md:p-8">
                              <div className="relative flex-1 bg-white rounded-3xl overflow-hidden shadow-sm border border-slate-100 p-4">
                                <img src={originalImage!} className="w-full h-full object-contain" alt="Original" />
                                <div className="absolute bottom-4 left-6 px-3 py-1 bg-slate-900/50 backdrop-blur-md text-[10px] text-white font-bold rounded-lg uppercase tracking-wider">Before</div>
                              </div>
                              <div className="relative flex-1 rounded-3xl overflow-hidden shadow-sm border border-slate-100 p-4" style={{ background: 'transparent' }}>
                                <img src={processedImage} className="relative z-10 w-full h-full object-contain" alt="After" />
                                <div className="absolute bottom-4 left-6 px-3 py-1 bg-indigo-600 text-[10px] text-white font-bold rounded-lg uppercase tracking-wider">After</div>
                              </div>
                            </div>
                          )}
                          <div className="absolute top-6 left-6 inline-flex items-center gap-2 px-3 py-1 bg-white border border-slate-100 rounded-full text-[10px] font-bold uppercase tracking-widest text-slate-400 shadow-sm z-30">
                            <CheckCircle2 className="w-3 h-3 text-green-500" />
                            AI Refined
                          </div>
                        </motion.div>
                      ) : null}
                    </AnimatePresence>
                  </div>

                  {/* Controls Overlay */}
                  {processedImage && !isProcessing && (
                    <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-40 flex items-center gap-4 px-6 py-3 bg-white/90 backdrop-blur-md rounded-2xl border border-slate-100 shadow-xl">
                      <div className="flex items-center gap-2 pr-4 border-r border-slate-100">
                        <button 
                          onClick={() => setPreviewBg('checkerboard')}
                          className={cn("w-6 h-6 rounded-md border border-slate-200", previewBg === 'checkerboard' && "ring-2 ring-indigo-600 ring-offset-2")}
                          style={{ backgroundImage: 'linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)', backgroundSize: '10px 10px', backgroundPosition: '0 0, 0 5px, 5px -5px, -5px 0px' }}
                        />
                        <button 
                          onClick={() => setPreviewBg('white')}
                          className={cn("w-6 h-6 rounded-md bg-white border border-slate-200", previewBg === 'white' && "ring-2 ring-indigo-600 ring-offset-2")}
                        />
                        <button 
                          onClick={() => setPreviewBg('black')}
                          className={cn("w-6 h-6 rounded-md bg-black border border-slate-400", previewBg === 'black' && "ring-2 ring-indigo-600 ring-offset-2")}
                        />
                        <div className="relative group">
                          <button 
                            className={cn("w-6 h-6 rounded-md border border-slate-200 flex items-center justify-center overflow-hidden", previewBg === 'custom' && "ring-2 ring-indigo-600 ring-offset-2")}
                            style={{ backgroundColor: customBgColor }}
                          >
                            <input 
                              type="color" 
                              value={customBgColor} 
                              onChange={(e) => {
                                setCustomBgColor(e.target.value);
                                setPreviewBg('custom');
                              }}
                              className="absolute inset-0 opacity-0 cursor-pointer"
                            />
                          </button>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        <button 
                          onClick={() => setViewMode('result')}
                          className={cn("px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-lg transition-all", viewMode === 'result' ? "bg-slate-900 text-white" : "text-slate-400 hover:text-slate-600")}
                        >
                          Result
                        </button>
                        <button 
                          onClick={() => setViewMode('comparison')}
                          className={cn("px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-lg transition-all", viewMode === 'comparison' ? "bg-slate-900 text-white" : "text-slate-400 hover:text-slate-600")}
                        >
                          Compare
                        </button>
                        <button 
                          onClick={() => setViewMode('side-by-side')}
                          className={cn("px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-lg transition-all", viewMode === 'side-by-side' ? "bg-slate-900 text-white" : "text-slate-400 hover:text-slate-600")}
                        >
                          Side
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </section>
        )}
      </main>

      <footer className="bg-slate-900 pt-12 pb-6 text-slate-400">
        <div className="max-w-7xl mx-auto px-4">
          <AdUnit className="mb-12 h-24 bg-slate-800/50 border-slate-700" slot="footer-horizontal" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12 text-center md:text-left">
            <div className="col-span-1 md:col-span-1 flex flex-col items-center md:items-start space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 bg-indigo-500 rounded-lg flex items-center justify-center">
                  <Zap className="w-4 h-4 text-white fill-white" />
                </div>
                <span className="text-lg font-black tracking-tight text-white font-display">ClearCut<span className="text-indigo-400">AI</span></span>
              </div>
              <p className="text-[13px] leading-relaxed max-w-xs mx-auto md:mx-0">
                The world's first fully private, on-device AI background remover. Professional results in seconds.
              </p>
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-full bg-slate-800 flex items-center justify-center hover:bg-indigo-500 transition-all cursor-pointer">
                  <svg className="w-3.5 h-3.5 fill-white" viewBox="0 0 24 24"><path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/></svg>
                </div>
                <div className="w-7 h-7 rounded-full bg-slate-800 flex items-center justify-center hover:bg-indigo-500 transition-all cursor-pointer">
                  <svg className="w-3.5 h-3.5 fill-white" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4s1.791-4 4-4 4 1.79 4 4-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
                </div>
              </div>
            </div>

            <div className="col-span-1 space-y-4">
              <h4 className="font-bold text-white uppercase tracking-widest text-[10px]">Product</h4>
              <ul className="space-y-2 text-[13px]">
                <li><a href="#" className="hover:text-indigo-400 transition-colors">Background Remover</a></li>
                <li><a href="#" className="hover:text-indigo-400 transition-colors">Batch Processing</a></li>
                <li><a href="#" className="hover:text-indigo-400 transition-colors">Signature Eraser</a></li>
              </ul>
            </div>

            <div className="col-span-1 space-y-4">
              <h4 className="font-bold text-white uppercase tracking-widest text-[10px]">Resources</h4>
              <ul className="space-y-2 text-[13px]">
                <li><a href="#" className="hover:text-indigo-400 transition-colors">API Docs</a></li>
                <li><a href="#" className="hover:text-indigo-400 transition-colors">Privacy Shield</a></li>
                <li><a href="#" className="hover:text-indigo-400 transition-colors">How it Works</a></li>
              </ul>
            </div>

            <div className="col-span-1 space-y-4">
              <h4 className="font-bold text-white uppercase tracking-widest text-[10px]">Legal</h4>
              <ul className="space-y-2 text-[13px]">
                <li><a href="#" className="hover:text-indigo-400 transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-indigo-400 transition-colors">Privacy Policy</a></li>
              </ul>
              <div className="mt-4 pt-4 border-t border-slate-800 flex flex-col items-center md:items-start">
                <button className="flex items-center gap-2 text-white font-bold text-xs">
                  <span className="text-lg">🇺🇸</span>
                  English
                </button>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-800 flex flex-col items-center text-center">
            <div className="text-[10px] font-medium uppercase tracking-[0.2em] text-slate-500">
              <p>© 2024 ClearCut AI. Built with Local AI Privacy.</p>
              <div className="flex justify-center gap-6 mt-3">
                <span>GDPR Compliant</span>
                <span>100% Free</span>
                <span>No Tracking</span>
              </div>
            </div>
            
            <div className="sr-only">
              ai background remover, automatic background remover, transparent background maker, erase image background, delete background from image, image background remover online, photo background remover free, remove white background from image, remove black background from image, remove object and background from photo, remove background from logo, remove background from product image, remove background from portrait photo, remove background from jpeg, remove background from jpg, remove background from png image, remove background from selfie, remove background from profile picture, remove background online free hd, best background remover tool, one click background remover, instant background remover, remove background without photoshop, remove background using ai, ai photo cutout tool, make transparent background online, transparent png maker, free online photo editor remove background, remove green screen background, remove video background online, remove background from youtube thumbnail, remove background from car photo, remove background from product photos for ecommerce, remove background for amazon product images, remove background for shopify products, remove background mobile app, remove background app for iphone, remove background android app, canva background remover, photoshop background remover tool, gimp remove background tutorial, powerpoint remove background image, remove background from signature, remove background from scanned document, remove watermark and background, remove image background in hd quality, bulk background remover, batch remove background images, remove background for passport photo, remove background for id photo, remove background and add white background, background eraser online free
            </div>
          </div>
        </div>
      </footer>

    </div>
  );
}
